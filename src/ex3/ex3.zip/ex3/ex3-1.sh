#!/bin/sh
echo "enter number"
read how
for ((i=0; i<how; i++))
do
	echo "hello world"
done
exit 0
